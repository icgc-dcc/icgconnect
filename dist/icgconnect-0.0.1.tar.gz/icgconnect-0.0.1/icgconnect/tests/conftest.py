import pytest

def pytest_test():
	exit()